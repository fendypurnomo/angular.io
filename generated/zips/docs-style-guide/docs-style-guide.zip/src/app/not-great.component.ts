import { Component } from '@angular/core';

@Component({
  selector: 'app-not-great',
})
export class NotGreatComponent {

  buggyFunction() {
    // things could be better here...
  }
}
